"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";

export type MidiMessageKind = "noteon" | "noteoff" | "program" | "cc" | "unknown";

export type MidiEvent = {
  kind: MidiMessageKind;
  channel: number; // 1-16
  note?: number; // 0-127
  velocity?: number; // 0-127
  program?: number; // 0-127
  cc?: number; // 0-127
  value?: number; // 0-127
  raw: Uint8Array;
};

export type MidiInputInfo = { id: string; name: string };

function parseMidiMessage(data: Uint8Array): MidiEvent {
  const status = data[0] ?? 0;
  const type = status & 0xf0;
  const channel = (status & 0x0f) + 1;

  // Note On: 0x90, Note Off: 0x80
  if (type === 0x90) {
    const note = data[1] ?? 0;
    const velocity = data[2] ?? 0;
    // Velocity 0 is conventionally Note Off
    if (velocity === 0) return { kind: "noteoff", channel, note, velocity, raw: data };
    return { kind: "noteon", channel, note, velocity, raw: data };
  }
  if (type === 0x80) {
    const note = data[1] ?? 0;
    const velocity = data[2] ?? 0;
    return { kind: "noteoff", channel, note, velocity, raw: data };
  }

  // Program Change: 0xC0
  if (type === 0xc0) {
    const program = data[1] ?? 0;
    return { kind: "program", channel, program, raw: data };
  }

  // Control Change: 0xB0
  if (type === 0xb0) {
    const cc = data[1] ?? 0;
    const value = data[2] ?? 0;
    return { kind: "cc", channel, cc, value, raw: data };
  }

  return { kind: "unknown", channel, raw: data };
}

export function midiToNoteName(midi: number): string {
  // Matches your sampler’s note strings like "C#4", "A0", etc.
  const names = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"];
  const name = names[midi % 12] ?? "C";
  const octave = Math.floor(midi / 12) - 1;
  return `${name}${octave}`;
}

export function useMidi() {
  const [supported, setSupported] = useState<boolean>(false);
  const [accessGranted, setAccessGranted] = useState<boolean>(false);
  const [inputs, setInputs] = useState<MidiInputInfo[]>([]);
  const [selectedInputId, setSelectedInputId] = useState<string>("");

  const midiAccessRef = useRef<MIDIAccess | null>(null);
  const activeInputRef = useRef<MIDIInput | null>(null);

  const [lastEvent, setLastEvent] = useState<MidiEvent | null>(null);

  const refreshInputs = useCallback(() => {
    const access = midiAccessRef.current;
    if (!access) return;

    const next: MidiInputInfo[] = [];
    access.inputs.forEach((input) => {
      next.push({ id: input.id, name: input.name || "MIDI Input" });
    });

    setInputs(next);

    // If nothing selected, auto-pick first
    if (!selectedInputId && next.length > 0) {
      setSelectedInputId(next[0]!.id);
    }
  }, [selectedInputId]);

  const requestAccess = useCallback(async () => {
    const hasMidi = typeof navigator !== "undefined" && "requestMIDIAccess" in navigator;
    setSupported(hasMidi);
    if (!hasMidi) return false;

    try {
      const access = await (navigator as any).requestMIDIAccess({ sysex: false });
      midiAccessRef.current = access;

      setAccessGranted(true);
      refreshInputs();

      access.onstatechange = () => refreshInputs();
      return true;
    } catch {
      setAccessGranted(false);
      return false;
    }
  }, [refreshInputs]);

  const bindInput = useCallback(
    (inputId: string, onEvent: (e: MidiEvent) => void) => {
      const access = midiAccessRef.current;
      if (!access) return;

      // Unbind previous
      if (activeInputRef.current) {
        activeInputRef.current.onmidimessage = null;
        activeInputRef.current = null;
      }

      const input = access.inputs.get(inputId) || null;
      activeInputRef.current = input;

      if (!input) return;

      input.onmidimessage = (msg) => {
        if (!msg.data) return;
        const data = new Uint8Array(msg.data);
        const evt = parseMidiMessage(data);
        setLastEvent(evt);
        onEvent(evt);
      };
    },
    []
  );

  // Convenience: map for UI label
  const selectedInputName = useMemo(() => {
    return inputs.find((i) => i.id === selectedInputId)?.name ?? "";
  }, [inputs, selectedInputId]);

  // Clean up on unmount
  useEffect(() => {
    return () => {
      if (activeInputRef.current) activeInputRef.current.onmidimessage = null;
    };
  }, []);

  return {
    supported,
    accessGranted,
    requestAccess,

    inputs,
    selectedInputId,
    setSelectedInputId,
    selectedInputName,

    bindInput,
    lastEvent,
  };
}